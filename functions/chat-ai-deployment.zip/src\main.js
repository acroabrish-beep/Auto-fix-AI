const extractMessage = (req) => {
  if (
    req.bodyJson &&
    Object.prototype.hasOwnProperty.call(req.bodyJson, 'message')
  ) {
    return req.bodyJson.message;
  }

  for (const body of [req.bodyText, req.bodyRaw]) {
    if (typeof body !== 'string' || !body.trim()) continue;

    try {
      const parsed = JSON.parse(body);
      if (typeof parsed === 'string') return parsed;
      if (parsed && Object.prototype.hasOwnProperty.call(parsed, 'message')) {
        return parsed.message;
      }
    } catch {
      return body;
    }
  }

  return undefined;
};

export default async ({ req, res, log, error }) => {
  log('Raw Body: ' + req.bodyRaw);
  log('JSON Body: ' + JSON.stringify(req.bodyJson));

  if (req.method !== 'POST') {
    return res.json({ error: 'Method not allowed. Use POST.' }, 405);
  }

  const message = extractMessage(req);

  if (typeof message !== 'string' || !message.trim()) {
    return res.json(
      {
        error: 'No message provided',
        received: req.bodyRaw ?? req.bodyText ?? req.bodyJson ?? null,
      },
      400
    );
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    error('Missing OPENAI_API_KEY environment variable.');
    return res.json({ error: 'Chat AI is not configured.' }, 500);
  }

  log('Chat request received.');

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content:
              'You are AutoFix AI, an automotive learning, diagnosis and repair assistant. ' +
              'Give practical, safety-conscious guidance in clear, concise language. ' +
              'Always remind the user to consult a qualified mechanic for safety-critical work.',
          },
          { role: 'user', content: message.trim() },
        ],
        temperature: 0.7,
        max_tokens: 500,
      }),
    });

    if (!response.ok) {
      error(`OpenAI request failed with status ${response.status}.`);
      return res.json({ error: 'Failed to communicate with AI provider.' }, 502);
    }

    const result = await response.json();
    const reply = result?.choices?.[0]?.message?.content?.trim();

    if (!reply) {
      error('OpenAI returned an empty chat response.');
      return res.json({ error: 'AI provider returned an empty response.' }, 502);
    }

    return res.json({ reply });
  } catch (err) {
    error(`Chat function request failed: ${err?.message || 'unknown error'}`);
    return res.json({ error: 'An internal error occurred.' }, 500);
  }
};