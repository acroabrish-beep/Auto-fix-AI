/*
  APPWRITE FUNCTION: diagnostic-ai

  This function now handles two kinds of requests:
  1. Admin actions: { action, payload }
  2. Automotive diagnostics: { description, vehicleId, symptoms, ... }
     or { message } for a simple diagnostic prompt.
*/

const endpoint = process.env.APPWRITE_ENDPOINT || 'https://fra.cloud.appwrite.io/v1';
const projectId = process.env.APPWRITE_PROJECT_ID;
const apiKey = process.env.APPWRITE_API_KEY;
const databaseId = process.env.APPWRITE_DATABASE_ID || 'autofix-ai-db';
const openAiApiKey = process.env.OPENAI_API_KEY;

async function appwriteRequest(path, options = {}) {
  if (!projectId || !apiKey) {
    throw new Error('Missing APPWRITE_PROJECT_ID or APPWRITE_API_KEY.');
  }

  const response = await fetch(`${endpoint}${path}`, {
    ...options,
    headers: {
      'X-Appwrite-Project': projectId,
      'X-Appwrite-Key': apiKey,
      'Content-Type': 'application/json',
      Accept: 'application/json',
      ...(options.headers || {}),
    },
  });

  const text = await response.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }
  }

  if (!response.ok) {
    throw new Error(data?.message || data?.error || text || `Appwrite request failed with ${response.status}`);
  }

  return data;
}

function queryEqual(field, value) {
  return encodeURIComponent(JSON.stringify({
    method: 'equal',
    attribute: field,
    values: [String(value)],
  }));
}

async function findProfile(userId) {
  const result = await appwriteRequest(
    `/databases/${databaseId}/collections/profiles/documents?queries[]=${queryEqual('userId', userId)}&limit=1`
  );
  return result?.documents?.[0] || null;
}

async function findProfileByEmail(email) {
  const query = queryEqual('email', email);
  console.log(`Finding profile by email. Query: ${decodeURIComponent(query)}`);
  const result = await appwriteRequest(
    `/databases/${databaseId}/collections/profiles/documents?queries[]=${query}&limit=1`
  );
  console.log(`Profile lookup returned ${result?.documents?.length || 0} document(s).`);
  if (!result?.documents?.length) {
    throw new Error('User with this email does not exist. Please register them first.');
  }
  return result.documents[0];
}

async function writeAuditLog(actorId, action, targetId, details) {
  await appwriteRequest(`/databases/${databaseId}/collections/audit_logs/documents`, {
    method: 'POST',
    body: JSON.stringify({
      documentId: 'unique()',
      data: {
        actorId: actorId || 'unknown',
        action,
        targetId,
        details,
        timestamp: new Date().toISOString(),
      },
      permissions: ['read("users")'],
    }),
  });
}

async function changeRole(payload) {
  const { userId, role, actorId } = payload || {};
  if (!userId || !role) throw new Error('userId and role are required.');

  const profile = await findProfile(userId);
  if (!profile) throw new Error('Profile not found.');

  await appwriteRequest(`/databases/${databaseId}/collections/profiles/documents/${profile.$id}`, {
    method: 'PATCH',
    body: JSON.stringify({ data: { role } }),
  });

  await writeAuditLog(actorId || userId, 'change_role', profile.$id, `Changed role from ${profile.role} to ${role}`);
  return { userId, role };
}

async function setProfileStatus(userId, status, actorId, action) {
  if (!userId || !status) throw new Error('userId and status are required.');

  const profile = await findProfile(userId);
  if (!profile) throw new Error('Profile not found.');

  await appwriteRequest(`/databases/${databaseId}/collections/profiles/documents/${profile.$id}`, {
    method: 'PATCH',
    body: JSON.stringify({ data: { status } }),
  });

  await writeAuditLog(actorId || userId, action, profile.$id, `Set user status to ${status}`);
  return { userId, status };
}

async function approveApplication(payload) {
  const { applicationId, actorId } = payload || {};
  if (!applicationId) throw new Error('applicationId is required.');

  const application = await appwriteRequest(
    `/databases/${databaseId}/collections/applications/documents/${applicationId}`
  );

  const collectionId = application.type === 'garage' ? 'garages' : 'schools';
  const ownerField = application.type === 'garage' ? 'ownerId' : 'adminId';

  const created = await appwriteRequest(`/databases/${databaseId}/collections/${collectionId}/documents`, {
    method: 'POST',
    body: JSON.stringify({
      documentId: 'unique()',
      data: {
        name: application.details || `${application.type} application`,
        location: '',
        [ownerField]: application.applicantId,
        status: 'active',
      },
      permissions: ['read("users")'],
    }),
  });

  await appwriteRequest(`/databases/${databaseId}/collections/applications/documents/${applicationId}`, {
    method: 'PATCH',
    body: JSON.stringify({
      data: { status: 'approved' },
    }),
  });

  await writeAuditLog(actorId || 'admin', 'approve_application', applicationId, `Approved ${application.type} application`);
  return { applicationId, createdId: created.$id, type: application.type };
}

async function rejectApplication(payload) {
  const { applicationId, actorId } = payload || {};
  if (!applicationId) throw new Error('applicationId is required.');

  await appwriteRequest(`/databases/${databaseId}/collections/applications/documents/${applicationId}`, {
    method: 'PATCH',
    body: JSON.stringify({
      data: { status: 'rejected' },
    }),
  });

  await writeAuditLog(actorId || 'admin', 'reject_application', applicationId, 'Rejected application');
  return { applicationId, status: 'rejected' };
}

async function setInstitutionStatus(payload) {
  const { collectionId, id, status, actorId } = payload || {};
  if (!collectionId || !id || !status) {
    throw new Error('collectionId, id, and status are required.');
  }
  if (!['schools', 'garages'].includes(collectionId)) {
    throw new Error('Only schools and garages can be updated.');
  }

  await appwriteRequest(`/databases/${databaseId}/collections/${collectionId}/documents/${id}`, {
    method: 'PATCH',
    body: JSON.stringify({
      data: { status },
    }),
  });

  await writeAuditLog(actorId || 'admin', 'set_institution_status', id, `Set ${collectionId} ${id} to ${status}`);
  return { collectionId, id, status };
}

async function createInstitution(payload) {
  const { name, location, type, adminEmail, actorId } = payload || {};
  if (!name || !location || !type || !adminEmail) {
    throw new Error('name, location, type, and adminEmail are required.');
  }

  console.log(`Creating ${type} institution: ${name}`);
  const collectionId = type === 'garage' ? 'garages' : 'schools';
  const ownerField = type === 'garage' ? 'ownerId' : 'adminId';
  const role = type === 'garage' ? 'garage_admin' : 'tvet_admin';

  const institution = await appwriteRequest(`/databases/${databaseId}/collections/${collectionId}/documents`, {
    method: 'POST',
    body: JSON.stringify({
      documentId: 'unique()',
      data: {
        name,
        location,
        [ownerField]: '',
        status: 'active',
      },
      permissions: ['read("users")'],
    }),
  });
  console.log(`Created institution: ${institution.$id}`);

  const profile = await findProfileByEmail(adminEmail);
  if (!profile) {
    throw new Error('No profile found for the provided admin email.');
  }
  console.log(`Found admin profile: ${profile.$id} (${profile.email})`);

  await appwriteRequest(`/databases/${databaseId}/collections/profiles/documents/${profile.$id}`, {
    method: 'PATCH',
    body: JSON.stringify({
      data: {
        role,
        ...(type === 'garage' ? { garageId: institution.$id } : { institutionId: institution.$id }),
      },
    }),
  });
  console.log(`Updated profile ${profile.$id} to ${role}`);

  await writeAuditLog(actorId || 'admin', 'create_institution', institution.$id, `Created ${type} ${name}`);
  return { institutionId: institution.$id, adminUserId: profile.userId, role };
}

async function runAdminAction(action, actionPayload, actorId) {
  switch (action) {
    case 'change_role':
      return await changeRole({ ...actionPayload, actorId });
    case 'suspend_user':
      return await setProfileStatus(actionPayload.userId, 'suspended', actorId, 'suspend_user');
    case 'activate_user':
      return await setProfileStatus(actionPayload.userId, 'active', actorId, 'activate_user');
    case 'approve_application':
      return await approveApplication({ ...actionPayload, actorId });
    case 'reject_application':
      return await rejectApplication({ ...actionPayload, actorId });
    case 'set_institution_status':
      return await setInstitutionStatus({ ...actionPayload, actorId });
    case 'create_institution':
      return await createInstitution({ ...actionPayload, actorId });
    default:
      throw new Error(`Unknown action: ${action}`);
  }
}

async function runDiagnostic(payload) {
  if (!openAiApiKey) {
    throw new Error('AI diagnostics is not configured yet. Please add OPENAI_API_KEY to the function environment.');
  }

  const vehicleId = payload?.vehicleId;
  const description = payload?.description || payload?.message;
  const symptoms = payload?.symptoms;
  const warningLights = payload?.warningLights;
  const timing = payload?.timing;

  if (!description) {
    throw new Error('Problem description is required.');
  }

  const prompt = `
    You are a professional automotive diagnostic assistant.
    Analyze the following vehicle problem and provide a structured JSON response.

    Vehicle ID: ${vehicleId}
    Problem Description: ${description}
    Symptoms: ${symptoms?.join?.(', ') || symptoms || 'None specified'}
    Warning Lights: ${warningLights?.join?.(', ') || warningLights || 'None'}
    Timing: ${timing}

    Respond ONLY with a valid JSON object following this structure:
    {
      "summary": "Short overview of the issue",
      "possibleCauses": [
        { "title": "Cause Name", "description": "Short explanation", "probability": 0.0-1.0 }
      ],
      "recommendedChecks": [
        { "title": "Check Name", "description": "What to do", "toolsRequired": ["Tool 1", "Tool 2"] }
      ],
      "nextSteps": ["Step 1", "Step 2"],
      "safetyNotes": ["Safety Warning 1"],
      "confidence": 0.0-1.0,
      "disclaimer": "Safety disclaimer text"
    }
  `;

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${openAiApiKey}`,
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are an expert automotive mechanic providing diagnostic guidance in JSON format.' },
        { role: 'user', content: prompt },
      ],
      response_format: { type: 'json_object' },
      temperature: 0.7,
    }),
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData?.error?.message || 'Failed to communicate with AI provider.');
  }

  const aiData = await response.json();
  return JSON.parse(aiData.choices[0].message.content);
}

export default async (context) => {
  const { req, res, log, error } = context;

  if (req.method !== 'POST') {
    return res.json({ error: 'Method not allowed. Use POST.' }, 405);
  }

  let payload;
  try {
    payload = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
  } catch {
    return res.json({ error: 'Invalid JSON payload.' }, 400);
  }

  log(`Received ${req.method} request`);
  log(`Payload action: ${payload?.action || '(diagnostic)'}`);
  log(`Actor header: ${req.headers['x-appwrite-user-id'] || '(not provided)'}`);

  // Admin actions take priority when an action is present.
  if (payload?.action) {
    const actorId = req.headers['x-appwrite-user-id'] || payload?.payload?.actorId;
    if (!actorId) {
      return res.json({ error: 'Authentication required.' }, 401);
    }

    try {
      log(`Admin action requested: ${payload.action} by ${actorId}`);
      const actorProfileResult = await appwriteRequest(
        `/databases/${databaseId}/collections/profiles/documents?queries[]=${queryEqual('userId', actorId)}&limit=1`
      );
      const actorProfile = actorProfileResult?.documents?.[0];
      log(`Actor profile found: ${Boolean(actorProfile)}, role: ${actorProfile?.role}`);
      if (!actorProfile || actorProfile.role !== 'global_admin') {
        return res.json({ error: 'Global admin access required.' }, 403);
      }

      log(`Admin action: ${payload.action} by ${actorId}`);
      const result = await runAdminAction(payload.action, payload.payload || {}, actorId);
      return res.json({ success: true, data: result });
    } catch (err) {
      error(err?.message || 'Admin action failed.');
      return res.json({ error: err?.message || 'Admin action failed.' }, 500);
    }
  }

  // Diagnostic flow.
  try {
    if (!openAiApiKey) {
      return res.json(
        { error: 'AI diagnostics is not configured yet. Please add OPENAI_API_KEY to the function environment.' },
        500
      );
    }

    const result = await runDiagnostic(payload);
    return res.json(result);
  } catch (err) {
    error(err?.message || 'Diagnostic failed.');
    return res.json({ error: err?.message || 'An internal error occurred during analysis.' }, 500);
  }
};
