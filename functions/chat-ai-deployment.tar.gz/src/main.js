export default async ({ req, res, log, error }) => {
  let message = "";

  try {
    const rawBody = req.bodyRaw || req.bodyText || "";
    if (rawBody) {
      const parsed = JSON.parse(rawBody);
      message = parsed.message || "";
    }
  } catch (e) {
    message = req.bodyRaw || "";
  }

  if (!message) {
    return res.json({ error: "No message provided" }, 400);
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.json({ error: "Gemini API Key not configured" }, 500);
  }

  try {
    // ወቅታዊው የGoogle Gemini ሞዴል (gemini-3.5-flash)
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=${apiKey}`;
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 20000); // ለ20 ሰከንድ ብቻ እንዲጠብቅ

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        contents: [{
          parts: [{ 
            text: `System: You are AutoFix AI, an expert automotive mechanic. Diagnose the user's car problem based on their description. Provide: 1. Possible Issue, 2. Severity, 3. Recommended Steps, 4. Estimated Cost in ETB.\n\nUser: ${message}` 
          }]
        }]
      }),
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);

    const data = await response.json();

    if (data.error) {
      error(data.error.message);
      return res.json({ error: data.error.message }, 500);
    }

    const reply = data.candidates[0].content.parts[0].text;
    return res.json({ reply: reply });

  } catch (err) {
    if (err.name === 'AbortError') {
      return res.json({ error: "The AI took too long to respond. Please check your API key quota." }, 504);
    }
    error(err.message);
    return res.json({ error: "Failed to connect to AI" }, 500);
  }
};